import { Component, OnInit } from '@angular/core';
import { CommonService } from './common.service'; // Adjust the path if necessary
import { User } from './user.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  users: User[] = [];

  constructor(private commonService: CommonService) {}

  ngOnInit() {
    this.commonService.getUsers().subscribe((data: User[]) => {
      this.users = data;
    });
  }

  addUser() {
    const newUser: User = {
      firstName: 'Jane',
      lastName: 'Doe',
      email: 'jane.doe@example.com',
      password: 'password123',
    };
    this.commonService.createUser(newUser).subscribe((user: User) => {
      this.users.push(user);
    });
  }
}
