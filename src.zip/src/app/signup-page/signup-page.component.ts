import { Component } from '@angular/core';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup-page.component.html',
  styleUrls: ['./signup-page.component.css']
})
export class SignupPageComponent {
  firstName: string = '';
  lastName: string = '';
  email: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private commonService: CommonService, private router: Router) {}

  onSignup() {
    const newUser = {
      firstName: this.firstName,
      lastName: this.lastName,
      email: this.email,
      password: this.password
    };

    this.commonService.createUser(newUser).subscribe(
      response => {
        alert('User created successfully! Please log in.');
        this.router.navigate(['/login']); // Redirect to login page
      },
      error => {
        alert('ERROR CREATING USER!');
        this.errorMessage = 'Error during signup: ' + error.message;
      }
    );
  }
}
