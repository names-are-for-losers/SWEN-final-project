import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  // Send user data to the backend
  signupUser(userData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/signup`, userData);
  }

  // Send login data to the backend
  loginUser(loginData: { email: string; password: string }): Observable<any> {
    return this.http.post(`${this.baseUrl}/login`, loginData);
  }

  // Fetch users from the backend
  getUsers(): Observable<any> {
    return this.http.get(`${this.baseUrl}/api/users`);
  }
}
