import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent {
  constructor(private commonService: CommonService, private router: Router) {}

  onLogin(loginForm: any) {
    if (loginForm.valid) {
      this.commonService.loginUser(loginForm.value).subscribe(
        response => {
          alert('Login successful!');
          // Navigate to homepage or dashboard
          this.router.navigate(['/home']);
        },
        error => {
          alert('Invalid login credentials.');
        }
      );
    }
  }
}
