import { Component, OnInit } from '@angular/core';
import { ApiService } from 'C:/Users/slind/OneDrive/Documents/document_stuff/Personal/Important_stuff/Educational_Docs/RIT_university/Work/Year_3/Intro_to_software_engineering_261_(600)/file/myApplication/src/app/services/api.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css'],
})
export class LoginPageComponent implements OnInit {
  loginData = { email: '', password: '' };
  users: any[] = []; // Array to store user data

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    // Fetch users when the component loads
    this.apiService.getUsers().subscribe(
      (data) => {
        this.users = data; // Assign the response data to the users array
      },
      (error) => {
        console.error('Error fetching users:', error);
      }
    );
  }

  onSubmit() {
    this.apiService.loginUser(this.loginData).subscribe(
      (response) => {
        console.log('Login successful:', response);
        // Handle successful login, e.g., redirect to dashboard
      },
      (error) => {
        console.error('Login failed', error);
      }
    );
  }
}

