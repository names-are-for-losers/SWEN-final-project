package app;

public class calculator {
  private int result;
}
